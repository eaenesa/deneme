var kullanicilar = [{kullaniciAdi:"admin", parola:"psw"},
{kullaniciAdi:"enes", parola:"psw"}] ;

var girilenkullaniciAdi;
var girilenparola;
var x;
function kontrolEt(){
   girilenkullaniciAdi= document.getElementById("kullaniciAdi").value;
   girilenparola= document.getElementById("parola").value;

for(x of kullanicilar) {
   if( (x.kullaniciAdi == girilenkullaniciAdi) && (x.parola == girilenparola))  {

      return true;

   }
   else {
      return false;
   }
}



}

function girisOnayi(){
kontrolEt();

if(kontrolEt()) {
window.open("dashboard-index.html","_self");

} 

else {
   alert("Hatalı kullanıcı adı yada parola yeniden deneyiniz...")
}



}